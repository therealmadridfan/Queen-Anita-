// groupTools.js content for Queen Anita v4
