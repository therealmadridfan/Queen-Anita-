const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');
const axios = require('axios');

const PREFIX = "/";
const client = new Client({
    authStrategy: new LocalAuth()
});

client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
    console.log("📲 Scan the QR code to log in.");
});

client.on('ready', () => {
    console.log('✅ Queen Anita v4 is online!');
});

client.on('message', async (msg) => {
    const body = msg.body;
    if (!body.startsWith(PREFIX)) return;

    const chat = body.slice(PREFIX.length).trim().toLowerCase();
    const args = chat.split(" ");
    const command = args.shift();

    if (command === "menu") {
        const time = new Date().toLocaleTimeString();
        const date = new Date().toDateString();
        const username = msg._data.notifyName || msg._data.pushname || "null";

        const menu = `🚀 *_Buckle up ${username}, Good Night 🌙! We're going on an adventure!_* 🚀
📋 *_Quote of the day: I'm on a whiskey diet. I've lost three days already._* 📋
◈╭──❍「 *USER INFO* 」❍
◈├• 🦸 *Owner:* Dominion
◈├• 🏆 *Rank:* Tadpole
◈├• 🎮 *XP:* 87 
◈├• 🎩 *USER*: ${username}
◈╰─┬─★─☆──♪♪─❍
◈╭─┴❍「 *BOT STATUS* 」❍
◈├• 📆  *Date:* ${date}
◈├• ⏲️  *Time:* ${time}
◈├• 🤡  *Bot:* Queen Anita v4
◈├• 📣  *Prefix:* ${PREFIX}
◈├• 🕓  *Uptime:* Running!
◈├• 💌  *Database:* 0 of 467 
◈├• 📚  *Total Users:* 467
◈╰─┬─★─☆──♪♪─❍
◈╭─┴❍「 *MAIN MENU* 」❍
◈├• *allmenu*
◈├• *aimenu*
◈├• *aeditor*
◈├• *animemenu*
◈├• *autoreact*
◈├• *botmenu*
◈├• *dlmenu*
◈├• *economy*
◈├• *enable*
◈├• *funmenu*
◈├• *gamesmenu*
◈├• *groupmenu*
◈├• *infoanime*
◈├• *listmenu*
◈├• *listplugin*
◈├• *logomenu*
◈├• *makermenu*
◈├• *menu*
◈├• *menu3*
◈├• *menu4*
◈├• *nsfwmenu*
◈├• *randompic*
◈├• *randomvid*
◈├• *stickermenu*
◈├• *textpro*
◈├• *toolsmenu*
◈├• *ownermenu*
◈├• *setprivacy*
◈╰─♪♪─★─☆──♪♪─❍
© *Queen Anita v4*

> 💡 *_Remember, when in doubt, use /listmenu or /help It's like my magic spell book!_* 💡`;

        msg.reply(menu);
    }

    if (command === "githubstalk") {
        const username = args[0];
        if (!username) return msg.reply("❌ Please provide a GitHub username.");
        try {
            const res = await axios.get(`https://api.github.com/users/${username}`);
            const data = res.data;

            const info = `👤 *Username:* ${data.name || data.login}
🔗 *GitHub:* ${data.html_url}
📝 *Bio:* ${data.bio || "N/A"}
📊 *Repos:* ${data.public_repos}
👥 *Followers:* ${data.followers} | Following: ${data.following}`;

            const avatar = await MessageMedia.fromUrl(data.avatar_url);
            await msg.reply(avatar, msg.from, { caption: info });
        } catch (e) {
            msg.reply("❌ Failed to fetch GitHub user.");
        }
    }
});

client.initialize();

// Keep-alive server for Replit
const app = express();
app.get("/", (_, res) => res.send("👑 Queen Anita v4 is alive!"));
app.listen(3000, () => console.log("🌐 Keep-alive server running"));